require('./angular');
module.exports = angular;
